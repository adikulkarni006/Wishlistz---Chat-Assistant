export const faqs = [
  {
    keywords: ["return", "refund"],
    answer: "Returns are accepted within 7 days of delivery."
  },
  {
    keywords: ["delivery", "shipping"],
    answer: "Delivery takes 3–5 business days."
  },
  {
    keywords: ["payment", "cod"],
    answer: "We support UPI, cards, and Cash on Delivery."
  }
];
