export function getIndexFromText(text) {
  const map = {
    first: 0,
    second: 1,
    third: 2,
    fourth: 3,
    fifth: 4
  };

  for (const key in map) {
    if (text.includes(key)) return map[key];
  }

  return null;
}
